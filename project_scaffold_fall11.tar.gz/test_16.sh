#!/bin/csh
./main16 1 1
./main16 0 0
./main16 0 1
./main16 1 0
./main16 32 32
./main16 64 64
./main16 480 480
./main16 4064 4064
./main16 32736 32736
./main16 32 64
./main16 32 480
./main16 32 4064
./main16 32 32736
./main16 480 4064
./main16 480 32736
./main16 4064 32736






