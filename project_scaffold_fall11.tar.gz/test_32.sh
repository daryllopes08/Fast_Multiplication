#!/bin/csh
./main32 1 1
./main32 0 0
./main32 0 1
./main32 1 0
./main32 32 32
./main32 64 64
./main32 480 480
./main32 4064 4064
./main32 32736 32736
./main32 32 64
./main32 32 480
./main32 32 4064
./main32 32 32736
./main32 480 4064
./main32 480 32736
./main32 4064 32736






