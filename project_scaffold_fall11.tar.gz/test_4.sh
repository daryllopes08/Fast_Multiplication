#!/bin/csh
./main4 1 1
./main4 0 0
./main4 0 1
./main4 1 0
./main4 32 32
./main4 64 64
./main4 480 480
./main4 4064 4064
./main4 32736 32736
./main4 32 64
./main4 32 480
./main4 32 4064
./main4 32 32736
./main4 480 4064
./main4 480 32736
./main4 4064 32736






